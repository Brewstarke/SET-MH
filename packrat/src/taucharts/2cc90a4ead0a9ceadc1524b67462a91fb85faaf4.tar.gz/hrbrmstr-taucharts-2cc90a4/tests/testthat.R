library(testthat)
library(taucharts)

test_check("taucharts")
