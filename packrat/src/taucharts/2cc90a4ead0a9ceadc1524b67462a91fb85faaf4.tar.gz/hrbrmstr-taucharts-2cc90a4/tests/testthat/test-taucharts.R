context("basic functionality")
test_that("we can do something", {

  #expect_that(some_function(), is_a("data.frame"))

})
